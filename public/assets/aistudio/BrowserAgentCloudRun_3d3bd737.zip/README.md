# Browser Agent — Cloud Run

A deployable starter agent: FastAPI + Playwright Chromium + Gemini. It can inspect visible page content, navigate, click, type, fill forms, press keys, scroll and extract/summarize text. Each task uses a fresh isolated browser session.

## Deploy
1. Create a Gemini API key in Google AI Studio.
2. In Google Cloud Console, select a project and enable Cloud Run and Cloud Build. Billing may be required.
3. Extract this ZIP in Google Cloud Shell or a computer with Google Cloud CLI.
4. From this folder run:

```bash
gcloud run deploy browser-agent --source . --region asia-south1 --allow-unauthenticated --set-env-vars GEMINI_API_KEY=YOUR_GEMINI_KEY,AGENT_API_KEY=YOUR_LONG_RANDOM_SECRET
```

Replace both example values. Do not paste real keys into source code or public repositories. Homepage is public, but `/run` requires the bearer token if AGENT_API_KEY is set. For stricter security use `--no-allow-unauthenticated` and Google IAM.

## Use
Open the Cloud Run URL, enter a task, optional starting URL and API token. Example: “Open https://example.com and summarize the page.”
API: `POST /run` with JSON `{"task":"Open https://example.com and summarize it","start_url":"https://example.com","max_steps":8}`. Header: `Authorization: Bearer YOUR_LONG_RANDOM_SECRET`.
Endpoints: `/` UI, `/health`, `/docs`.

## Environment variables
`GEMINI_API_KEY` required; `AGENT_API_KEY` recommended; `GEMINI_MODEL` defaults to `gemini-2.5-flash`; `MAX_STEPS` defaults to 15.

## Limitations and safety
This is a practical starter, not a perfect human replacement. Dynamic sites can fail; login and CAPTCHA challenges may require you to intervene. It does not bypass protections. It pauses before actions that appear to purchase, pay, send, delete, publish, or submit consequential forms. It does not retain cookies between tasks. The model can make mistakes.

Before exposing it to multiple customers, add user accounts, rate limits, per-user quotas, task timeouts, usage monitoring, secret management, browser isolation, SSRF protections against internal/private IPs and cloud metadata endpoints, and explicit confirmation workflows. Never allow untrusted users to access private/internal network addresses. Cloud Run and Gemini usage may cost money.

Troubleshooting: 503 means configure GEMINI_API_KEY; 401 means provide the matching token; 429 means check Gemini quota and reduce max_steps.
